/**
 * Write a description of class GestionDeBiblioteca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
@SuppressWarnings("all")

public class GestionBiblioteca{
    public static void main(String[] args) {

        ControladorArchivos control = new ControladorArchivos("socios.dat","prestamos.dat","libros.dat");
        Biblioteca biblio = new Biblioteca("Aguante POO");
        VistaBiblioteca vista = new VistaBiblioteca(biblio, control);
        BibliotecaControlador controlVista = new BibliotecaControlador(vista, biblio);
        control.cargarDatos(biblio);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

}
