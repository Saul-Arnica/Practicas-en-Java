 
/**
 * Clase PrestamoInvalido
 * @author (Mercedess Fernandez) 
 * @version (1.0)4/11/2024
 */
public class PrestamoInvalidoException extends Exception
{
    /**
     * Constructor para objeto de clase PrestamoInvalido
     */
    public PrestamoInvalidoException(String p_mensaje)
    {
        super(p_mensaje);
    }
}
